

import 'package:flutter/cupertino.dart';

class PagePayments extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Page Payments'),);
  }
}