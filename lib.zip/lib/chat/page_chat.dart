

import 'package:flutter/cupertino.dart';

class PageChat extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Page Chat'),);
  }
}