import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class NavigationChat extends StatefulWidget {
  final _chatMessage;

  NavigationChat(this._chatMessage);

  @override
  State createState() {
      return NavigationChatState(_chatMessage);
  }
}

class NavigationChatState extends State<NavigationChat> {
  final int _chatMessage;

  NavigationChatState(this._chatMessage);

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: <Widget>[
        Icon(
          Icons.brightness_1,
          size: 18.0,
          color: Colors.redAccent,
        ),
        Text(
          '$_chatMessage',
          textAlign: TextAlign.center,
          style: new TextStyle(
            color: Colors.white,
            fontSize: 10.0,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}