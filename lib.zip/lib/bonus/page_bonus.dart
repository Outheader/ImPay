

import 'package:flutter/cupertino.dart';

class PageBonus extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Page Bonus'),);
  }
}