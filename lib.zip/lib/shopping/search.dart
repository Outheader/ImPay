

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Search extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40.0,
      child: Padding(
        padding: EdgeInsets.only(left: 12.0, right: 12.0),
        child: TextField(
          decoration: InputDecoration(
              hintText: 'Поиск',
              hintStyle: TextStyle(
                  fontSize: 15, color: Colors.white),
              filled: true,
              fillColor: Colors.white12,
              suffixIcon: Image.asset(
                  'assets/images/icon_search.png'),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                  width: 0,
                  style: BorderStyle.none,
                ),
              ),
              contentPadding:
              EdgeInsets.only(top: 20, left: 10)),
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}