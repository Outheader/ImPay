
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Profile extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(
        width: 34.0,
        height: 34.0,
        child: MaterialButton(onPressed: (){},
          padding: EdgeInsets.all(0.0),
          shape: CircleBorder(),
          child: Image.asset(
            'assets/images/profile_image.png',
            width: 34.0,
            height: 34.0,
          ),),),
      Padding(
        padding: EdgeInsets.fromLTRB(6.0, 0.0, 0.0, 0.0),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'Кирилл',
            style: TextStyle(
                color: Colors.white, fontSize: 20.0),
          ),
        ),
      )
    ],);
  }
}
