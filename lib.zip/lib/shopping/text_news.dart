

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled/main.dart';

class TextNews extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return Container(
      margin:
      EdgeInsets.only(top: 10.0, bottom: 10.0),
      child: Row(
        children: [
          Text(
            'НОВОСТИ',
            style: TextStyle(
                color: MyColors.grey, fontSize: 14),
          ),
          Spacer(
            flex: 1,
          ),
          MaterialButton(
            onPressed: () {},
            shape: CircleBorder(),
            child: Image.asset(
                'assets/images/icon_arrow_right.png'),
          )
        ],
      ),
    );
  }
}