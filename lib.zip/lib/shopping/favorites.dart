

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled/main.dart';

class Favorites extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          margin: EdgeInsets.only(top: 15.0),
          width: 76.0,
          height: 84.0,
          decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(
                  color: Colors.white,
                  style: BorderStyle.solid,
                  width: 0.0),
              borderRadius:
              BorderRadius.circular(6.0),
              boxShadow: [
                new BoxShadow(
                    color: Color(0x1a000000),
                    offset: new Offset(0.0, 0.0),
                    blurRadius: 7.0),
                new BoxShadow(
                    color: Color(0x1a000000),
                    offset: new Offset(3.0, 3.0),
                    blurRadius: 7.0)
              ]),
          child: MaterialButton(
            onPressed: () {},
            padding: EdgeInsets.all(0.0),
            shape: OutlineInputBorder(
                borderRadius:
                BorderRadius.circular(6.0),
                borderSide: BorderSide(
                    width: 0,
                    color: Colors.white,
                    style: BorderStyle.solid)),
            child: Container(
              padding: EdgeInsets.all(10.0),
              alignment: Alignment.centerLeft,
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [
                  Image.asset(
                    'assets/images/icon_my_payments.png',
                    width: 24.0,
                    height: 24.0,
                  ),
                  Container(
                    margin:
                    EdgeInsets.only(top: 12.0),
                    child: Text(
                      'Мои платежи',
                      maxLines: 2,
                      style: TextStyle(
                          fontSize: 11,
                          color: MyColors.grey_100),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Spacer(
          flex: 1,
        ),
        Container(
          margin: EdgeInsets.only(top: 15.0),
          width: 76.0,
          height: 84.0,
          decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(
                  color: Colors.white,
                  style: BorderStyle.solid,
                  width: 0.0),
              borderRadius:
              BorderRadius.circular(6.0),
              boxShadow: [
                new BoxShadow(
                    color: Color(0x1a000000),
                    offset: new Offset(0.0, 0.0),
                    blurRadius: 7.0),
                new BoxShadow(
                    color: Color(0x1a000000),
                    offset: new Offset(3.0, 3.0),
                    blurRadius: 7.0)
              ]),
          child: MaterialButton(
            onPressed: () {},
            padding: EdgeInsets.all(0.0),
            shape: OutlineInputBorder(
                borderRadius:
                BorderRadius.circular(6.0),
                borderSide: BorderSide(
                    width: 0,
                    color: Colors.white,
                    style: BorderStyle.solid)),
            child: Container(
              padding: EdgeInsets.all(10.0),
              alignment: Alignment.centerLeft,
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [
                  Image.asset(
                    'assets/images/icon_tickets.png',
                    width: 24.0,
                    height: 24.0,
                  ),
                  Container(
                    margin:
                    EdgeInsets.only(top: 12.0),
                    child: Text(
                      'Билеты',
                      maxLines: 2,
                      style: TextStyle(
                          fontSize: 11,
                          color: MyColors.grey_100),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Spacer(
          flex: 1,
        ),
        Container(
          margin: EdgeInsets.only(top: 15.0),
          width: 76.0,
          height: 84.0,
          decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(
                  color: Colors.white,
                  style: BorderStyle.solid,
                  width: 0.0),
              borderRadius:
              BorderRadius.circular(6.0),
              boxShadow: [
                new BoxShadow(
                    color: Color(0x1a000000),
                    offset: new Offset(0.0, 0.0),
                    blurRadius: 7.0),
                new BoxShadow(
                    color: Color(0x1a000000),
                    offset: new Offset(3.0, 3.0),
                    blurRadius: 7.0)
              ]),
          child: MaterialButton(
            onPressed: () {},
            padding: EdgeInsets.all(0.0),
            shape: OutlineInputBorder(
                borderRadius:
                BorderRadius.circular(6.0),
                borderSide: BorderSide(
                    width: 0,
                    color: Colors.white,
                    style: BorderStyle.solid)),
            child: Container(
              padding: EdgeInsets.all(10.0),
              alignment: Alignment.centerLeft,
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [
                  Image.asset(
                    'assets/images/icon_sales.png',
                    width: 24.0,
                    height: 24.0,
                  ),
                  Container(
                    margin:
                    EdgeInsets.only(top: 12.0),
                    child: Text(
                      'Карты лояльности',
                      maxLines: 2,
                      style: TextStyle(
                          fontSize: 11,
                          color: MyColors.grey_100),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Spacer(
          flex: 1,
        ),
        Container(
          margin:
          EdgeInsets.only(top: 15.0, right: 11.0),
          width: 76.0,
          height: 84.0,
          decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(
                  color: Colors.white,
                  style: BorderStyle.solid,
                  width: 0.0),
              borderRadius:
              BorderRadius.circular(6.0),
              boxShadow: [
                new BoxShadow(
                    color: Color(0x1a000000),
                    offset: new Offset(0.0, 0.0),
                    blurRadius: 7.0),
                new BoxShadow(
                    color: Color(0x1a000000),
                    offset: new Offset(3.0, 3.0),
                    blurRadius: 7.0)
              ]),
          child: MaterialButton(
            onPressed: () {},
            padding: EdgeInsets.all(0.0),
            shape: OutlineInputBorder(
                borderRadius:
                BorderRadius.circular(6.0),
                borderSide: BorderSide(
                    width: 0,
                    color: Colors.white,
                    style: BorderStyle.solid)),
            child: Container(
              padding: EdgeInsets.all(10.0),
              alignment: Alignment.centerLeft,
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [
                  Image.asset(
                    'assets/images/icon_qr.png',
                    width: 24.0,
                    height: 24.0,
                  ),
                  Container(
                    margin:
                    EdgeInsets.only(top: 12.0),
                    child: Text(
                      'QR - оплата',
                      maxLines: 2,
                      style: TextStyle(
                          fontSize: 11,
                          color: MyColors.grey_100),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}