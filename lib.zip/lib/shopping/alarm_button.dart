import 'package:flutter/material.dart';

class AlarmButton extends StatefulWidget {
  final int _countNotification;

  AlarmButton(this._countNotification);

  @override
  State createState() {
    return new _AlarmButtonState(_countNotification);
  }
}

class _AlarmButtonState extends State<AlarmButton> {
  int countNotification;

  _AlarmButtonState(this.countNotification);

  @override
  Widget build(BuildContext context) {
    if (countNotification > 0)
      return MaterialButton(
        minWidth: 0.0,
        padding: EdgeInsets.all(0.0),
        onPressed: () {
          setState(() {
            countNotification = 0;
          });
        },
        child: Stack(
          children: <Widget>[
            new Container(
              padding: EdgeInsets.all(10.0),
              child: Image.asset('assets/images/alarm.png'),
            ),
            new Positioned(
              top: 2.0,
              left: 22.0,
              child: Stack(
                alignment: Alignment.center,
                children: <Widget>[
                  Icon(
                    Icons.brightness_1,
                    size: 18.0,
                    color: Colors.redAccent,
                  ),
                  Text(
                    '$countNotification',
                    textAlign: TextAlign.center,
                    style: new TextStyle(
                      color: Colors.white,
                      fontSize: 10.0,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        shape: CircleBorder(),
      );

    return MaterialButton(
      minWidth: 0.0,
      padding: EdgeInsets.all(0.0),
      onPressed: () {
        setState(() {
          countNotification = 3;
        });
      },
      child: Stack(
        children: <Widget>[
          new Container(
            padding: EdgeInsets.all(10.0),
            child: Image.asset('assets/images/alarm.png'),
          ),
        ],
      ),
      shape: CircleBorder(),
    );
  }
}