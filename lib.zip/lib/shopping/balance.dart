

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Balance extends StatefulWidget{
  final double _balance;

  Balance(this._balance);

  @override
  State createState() {
    return new BalanceState(_balance);
  }
}

class BalanceState extends State<Balance>{
  double balance;

  BalanceState(this.balance);

  String balanceToStr(double balance) {
    String str2 = '';
    String str = balance.toString();
    //Получу левую чать
    int p = str.indexOf('.');
    String s1 = str.substring(0, p);
    //Получу правую часть
    String s2 = str.substring(p + 1);
    //Надо добавить пробелы в левой части по необходимости
    for (int i = s1.length - 1; i >= 0; i--) {
      str2 = s1[i] + str2;
      //Разделяю пробелами каждые 3 цифры
      if ((s1.length - i) % 3 == 0 && i > 0) str2 = ' ' + str2;
    }

    //Добавляю разделитель
    str2 += ',' + s2 + ' ₽';

    return str2;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(12.0, 7.0, 12.0, 17.0),
      child: Row(
        children: [
          Text(
            'Баланс кошелька ImPay',
            style: TextStyle(color: Colors.white),
          ),
          Spacer(
            flex: 1,
          ),
          Text(
            balanceToStr(balance),
            style: TextStyle(color: Colors.white),
          )
        ],
      ),
    );
  }
}