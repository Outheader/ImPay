import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled/main.dart';

class PageProfile extends StatefulWidget {
  @override
  State createState() {
    return PageProfileState();
  }
}

class PageProfileState extends State<PageProfile> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                MyColors.gradientTopBlue,
                MyColors.gradientBottomBlue
              ])),
          child: Container(
            margin: EdgeInsets.only(top: 33.0),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      width: 34.0,
                      height: 34.0,
                      margin: EdgeInsets.only(left: 5.0),
                      child: MaterialButton(
                        onPressed: () {},
                        padding: EdgeInsets.all(0.0),
                        child: Image.asset('assets/images/icon_arrow_left.png'),
                        shape: CircleBorder(),
                      ),
                    ),
                    Text(
                      'Профиль',
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    ),
                    Spacer(
                      flex: 1,
                    ),
                    Container(
                        width: 34.0,
                        height: 34.0,
                        margin: EdgeInsets.only(right: 8.0),
                        child: MaterialButton(
                          onPressed: () {},
                          padding: EdgeInsets.all(0.0),
                          child: Image.asset(
                              'assets/images/icon_profile_exit.png'),
                          shape: CircleBorder(),
                        ))
                  ],
                ),

                Container(
                  height: 10.0,
                  margin: EdgeInsets.only(top: 20.0),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.white, style: BorderStyle.solid),
                    borderRadius: BorderRadius.only(topLeft: Radius.circular(10.0), topRight: Radius.circular(10.0)),
                  ),
                )
              ],
            ),
          ),
        ),
        
        Image.asset('assets/images/profile_image.png')
      ],
    );
  }
}
