

import 'package:flutter/cupertino.dart';
import 'package:untitled/main.dart';

class TextFavorites extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.centerLeft,
      child: Text(
        'ИЗБРАННОЕ',
        style: TextStyle(
          fontSize: 14,
          color: MyColors.grey,
        ),
      ),
    );
  }
}