

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class News extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          Container(
            width: 180.0,
            height: 180.0,
            margin: EdgeInsets.only(right: 14.0),
            child: ClipRRect(
              borderRadius:
              BorderRadius.circular(15.0),
              child: MaterialButton(
                padding: EdgeInsets.all(0.0),
                onPressed: () {},
                child: Stack(
                  children: [
                    Image.asset(
                      'assets/images/news1.png',
                      fit: BoxFit.fill,
                      width: 180,
                    ),
                    Container(
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                Colors.black45
                              ],
                              begin:
                              Alignment.topCenter,
                              end: Alignment
                                  .bottomCenter)),
                    ),
                    Container(
                      width: double.infinity,
                      height: double.infinity,
                      alignment:
                      Alignment.bottomCenter,
                      padding: EdgeInsets.all(10.0),
                      child: Text(
                        'Суперакция от Веккер Закажи окно до конца сентября и получи мегаскидку плюсь бонусы на счёт.',
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.white),
                      ),
                    ),
                  ],
                ),
                shape: OutlineInputBorder(
                    borderRadius:
                    BorderRadius.circular(15.0),
                    borderSide: BorderSide(
                        width: 0.0,
                        color: Colors.black,
                        style: BorderStyle.solid)),
              ),
            ),
          ),
          Container(
            width: 180.0,
            height: 180.0,
            margin: EdgeInsets.only(right: 14.0),
            child: ClipRRect(
              borderRadius:
              BorderRadius.circular(15.0),
              child: MaterialButton(
                padding: EdgeInsets.all(0.0),
                onPressed: () {},
                child: Stack(
                  children: [
                    Image.asset(
                      'assets/images/news2.png',
                      fit: BoxFit.fill,
                      width: 180,
                    ),
                    Container(
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                Colors.black45
                              ],
                              begin:
                              Alignment.topCenter,
                              end: Alignment
                                  .bottomCenter)),
                    ),
                    Container(
                      width: double.infinity,
                      height: double.infinity,
                      alignment:
                      Alignment.bottomCenter,
                      padding: EdgeInsets.all(10.0),
                      child: Text(
                        'При заказе одной кружки кофе Вы получите 20 бонусов на счет.',
                        style: TextStyle(
                            fontSize: 14,
                            color: Colors.white),
                      ),
                    ),
                  ],
                ),
                shape: OutlineInputBorder(
                    borderRadius:
                    BorderRadius.circular(15.0),
                    borderSide: BorderSide(
                        width: 0.0,
                        color: Colors.black,
                        style: BorderStyle.solid)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}