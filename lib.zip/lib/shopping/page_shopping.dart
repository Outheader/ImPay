import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled/main.dart';
import 'package:untitled/shopping/News.dart';
import 'package:untitled/shopping/alarm_button.dart';
import 'package:untitled/shopping/balance.dart';
import 'package:untitled/shopping/favorites.dart';
import 'package:untitled/shopping/page_profile/page_profile.dart';
import 'package:untitled/shopping/profile.dart';
import 'package:untitled/shopping/search.dart';
import 'package:untitled/shopping/text_favorites.dart';
import 'package:untitled/shopping/text_news.dart';

bool showProfilePage = true;
late PageShoppingState pageShoppingState;

class PageShopping extends StatefulWidget {
  @override
  State createState() {
    pageShoppingState = PageShoppingState();
    return pageShoppingState;
  }
}

class PageShoppingState extends State<PageShopping> {
  final int countAlarm = 3;
  final double balance = 5485.67;

  @override
  Widget build(BuildContext context) {
    return showProfilePage ?
      SingleChildScrollView(
      child: Column(children: [
        Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                MyColors.gradientTopBlue,
                MyColors.gradientBottomBlue,
              ])),
          padding: EdgeInsets.only(top: 33.0),
          child: Column(children: [
            Container(
              padding: EdgeInsets.only(left: 12.0, right: 12.0),
              child: Row(
                children: [
                  Profile(),
                  Spacer(
                    flex: 1,
                  ),
                  AlarmButton(countAlarm),
                ],
              ),
            ),
            Balance(balance),
            Search(),
            Container(
              height: 10.0,
              margin: EdgeInsets.only(top: 14.0),
              width: double.infinity,
              decoration: BoxDecoration(
                  color: Colors.white,
                  border:
                      Border.all(style: BorderStyle.solid, color: Colors.white),
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10))),
            ),
          ]),
        ),
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.only(top: 27.0, left: 12.0),
          child: Column(
            children: [
              TextFavorites(),
              Favorites(),
              TextNews(),
              News(),
              /*Container(
                          // give it a width equals to the device screen
                          width: MediaQuery.of(context).size.width,
                          // give it a height equals to the device screen
                          height: MediaQuery.of(context).size.height,
                          color: Colors.red,
                        ),*/
              //Spacer(flex: 1,)
            ],
          ),
        )
      ]),
    ) :
    PageProfile();
  }
}
