import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:untitled/bonus/page_bonus.dart';
import 'package:untitled/chat/page_chat.dart';
import 'package:untitled/main/page_main.dart';
import 'package:untitled/payments/page_payments.dart';
import 'package:untitled/shopping/page_shopping.dart';

class MyColors {
  static const grey = Color(0xFF8A898E);
  static const grey_100 = Color(0xFF222A34);
  static const blue = Color(0xFF00A3FF);
  static const gradientTopBlue = Color(0xFF02A1FB);
  static const gradientBottomBlue = Color(0xFF0268C6);
}

class MainActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'title',
        home: MainActivityStatefulWidget());
  }
}

class MainActivityStatefulWidget extends StatefulWidget {
  @override
  State createState() {
    return _MainActivityStatefulWidgetState();
  }
}

class _MainActivityStatefulWidgetState
    extends State<MainActivityStatefulWidget> {
  int _selectedIndex = 2;
  int _chatMessage = 3;

  List<Widget> pages = <Widget>[
    PageChat(),
    PageMain(),
    PageShopping(),
    PagePayments(),
    PageBonus(),
  ];

  void _onItemTapped(int item) {
    setState(() {
      _selectedIndex = item;
      if (item == 0)
        _chatMessage = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages.elementAt(_selectedIndex),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(
              label: 'Чат',
              //activeIcon: NavigationChat(0),
              //icon: NavigationChat(_chatMessage),),
              activeIcon: MyIcon('assets/images/icon_chat_active.png', 0),
              icon:
                  MyIcon('assets/images/icon_chat_inactive.png', _chatMessage)),
          BottomNavigationBarItem(
              label: 'Главная',
              activeIcon: MyIcon('assets/images/icon_home_active.png', 0),
              icon:
                  MyIcon('assets/images/icon_home_inactive.png', 0)),
          BottomNavigationBarItem(
              label: 'Покупки',
              activeIcon: MyIcon('assets/images/icon_shopping_active.png', 0),
              icon: MyIcon(
                  'assets/images/icon_shopping_inactive.png', 0)),
          BottomNavigationBarItem(
              label: 'Платежи',
              activeIcon: MyIcon('assets/images/icon_payments_active.png', 0),
              icon: MyIcon(
                  'assets/images/icon_payments_inactive.png', 0)),
          BottomNavigationBarItem(
              label: 'Бонусы',
              activeIcon: MyIcon('assets/images/icon_bonus_active.png', 0),
              icon: MyIcon(
                  'assets/images/icon_bonus_inactive.png', 0)),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: MyColors.blue,
        selectedFontSize: 14,
        unselectedItemColor: MyColors.grey,
        unselectedFontSize: 14,
        showUnselectedLabels: true,
      ),
    );
  }
}

class MyIcon extends StatelessWidget {
  final String pathIcon;
  final int countMessages;
  final double iconWidth = 25.0;
  final double iconHeight = 25.0;
  final double containerWidth = 35.0;
  final double containerHeight = 35.0;

  MyIcon(this.pathIcon, this.countMessages);

  @override
  Widget build(BuildContext context) {
    if (countMessages > 0)
      return Container(
        width: containerWidth,
        height: containerHeight,
        child: Stack(
          alignment: Alignment.center,
          children: <Widget>[
            Image.asset(
              pathIcon,
              fit: BoxFit.scaleDown,
              width: iconWidth,
              height: iconHeight,
            ),
            Align(
              alignment: Alignment.topRight,
              child: Stack(
                alignment: Alignment.center,
                children: <Widget>[
                  Icon(
                    Icons.brightness_1,
                    size: 18.0,
                    color: Colors.redAccent,
                  ),
                  Text(
                    '$countMessages',
                    textAlign: TextAlign.center,
                    style: new TextStyle(
                      color: Colors.white,
                      fontSize: 10.0,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    else
      return Container(
        width: containerWidth,
        height: containerHeight,
        child: Stack(
          alignment: Alignment.center,
          children: <Widget>[
            Image.asset(
              pathIcon,
              fit: BoxFit.scaleDown,
              width: iconWidth,
              height: iconHeight,
            ),
          ],
        ),
      );
  }
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light
  ));
  runApp(MainActivity());
}
