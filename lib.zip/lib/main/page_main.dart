

import 'package:flutter/cupertino.dart';

class PageMain extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Page Main'),);
  }
}